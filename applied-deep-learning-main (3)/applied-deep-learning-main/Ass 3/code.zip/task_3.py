# based on https://github.com/milindmalshe/Fully-Connected-Neural-Network-PyTorch/blob/master/FCN_MNIST_Classification_PyTorch.py
from functools import reduce

import numpy as np
import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt

# Setup device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Hyperparameters
input_size = 784
hidden_size = 500
num_classes = 10
num_epochs = 5
batch_size = 100
learning_rate = 0.001

# MNIST dataset
train_dataset = torchvision.datasets.MNIST(root='./data/',
                                           train=True,
                                           transform=transforms.ToTensor(),
                                           download=True)

test_dataset = torchvision.datasets.MNIST(root='./data/',
                                          train=False,
                                          transform=transforms.ToTensor())
train_subset, val_subset = torch.utils.data.random_split(train_dataset, [50000, 10000],
                                                         generator=torch.Generator().manual_seed(1))

# Data loader
train_loader = torch.utils.data.DataLoader(dataset=train_subset,
                                           batch_size=batch_size,
                                           shuffle=False)

val_loader = torch.utils.data.DataLoader(dataset=val_subset,
                                         batch_size=batch_size,
                                         shuffle=False)

test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
                                          batch_size=batch_size,
                                          shuffle=False)


def main(seed):
    # Fully connected neural network
    class NeuralNet(nn.Module):
        def __init__(self, input_size, hidden_size, num_classes):
            super(NeuralNet, self).__init__()
            self.fc1 = nn.Linear(input_size, hidden_size)
            self.relu = nn.ReLU()
            self.fc2 = nn.Linear(hidden_size, num_classes)

        def forward(self, x):
            out = self.fc1(x)
            out = self.relu(out)
            out = self.fc2(out)
            return out

    model = NeuralNet(input_size, hidden_size, num_classes).to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # train the model
    print("size of dataset: ", len(train_loader.dataset))
    ete_eval = []
    total_step = len(train_loader)
    for epoch in range(num_epochs):
        accumulated_loss_test = 0
        accumulated_loss_val = 0
        for i, (images, labels) in enumerate(train_loader):
            images = images.reshape(-1, input_size).to(device)
            labels = labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            if (i + 1) % 300 == 0:
                print('Epoch [{}/{}], Step [{}/{}], Loss: {:.4f}'
                      .format(epoch + 1, num_epochs, i + 1, total_step, loss.item()))
        # every epoch
        with torch.no_grad():
            # val
            for images, labels in val_loader:
                images = images.reshape(-1, input_size).to(device)
                labels = labels.to(device)
                outputs = model(images)
                loss = criterion(outputs, labels)
                accumulated_loss_val += loss.item()
            # test
            for images, labels in test_loader:
                images = images.reshape(-1, input_size).to(device)
                labels = labels.to(device)
                outputs = model(images)
                loss = criterion(outputs, labels)
                accumulated_loss_test += loss.item()
            ete = accumulated_loss_test / len(test_loader.dataset)
            e_val = accumulated_loss_val / len(val_loader.dataset)
            ete_eval.append((ete, e_val))

    # plt.plot(ete_eval, label=f"E test seed={seed}")
    # plt.legend()
    return min(ete_eval, key=lambda x: x[1])


if __name__ == "__main__":
    final_errors = []
    for i in [4, 8, 15, 16, 23]:
        torch.manual_seed(i)
        print(f"------- NOW USING SEED {i} ----------")
        final_errors.append(main(i))
    std, mean = torch.std_mean(torch.tensor(final_errors))
    print(final_errors)
    print(f"std={std}, mean={mean}")
