# based on https://github.com/milindmalshe/Fully-Connected-Neural-Network-PyTorch/blob/master/FCN_MNIST_Classification_PyTorch.py
from functools import reduce

import numpy as np
import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import torch.utils.data as data_utils
from matplotlib.patches import Patch

COLORS = np.array(["red", "green", "blue", "yellow", "pink", "black", "orange", "purple", "cyan", "magenta"])

# Setup device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def main(params):
    torch.manual_seed(15)
    # Hyperparameters
    input_size = 784
    hidden_size, batch_size, learning_rate = params
    num_classes = 10
    num_epochs = 5

    # MNIST dataset
    train_dataset = torchvision.datasets.MNIST(root='./data/',
                                               train=True,
                                               transform=transforms.ToTensor(),
                                               download=True)

    test_dataset = torchvision.datasets.MNIST(root='./data/',
                                              train=False,
                                              transform=transforms.ToTensor())
    # SHRINK BY x10

    # train_indices = torch.arange(6000)
    # test_indices = torch.arange(1000)
    # train_dataset = data_utils.Subset(train_dataset, train_indices)
    # test_dataset = data_utils.Subset(test_dataset, test_indices)
    #
    # train_subset, val_subset = torch.utils.data.random_split(train_dataset, [5000, 1000],
    #                                                          generator=torch.Generator().manual_seed(1))

    # Data loader
    train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
                                               batch_size=batch_size,
                                               shuffle=False)
    #
    # val_loader = torch.utils.data.DataLoader(dataset=val_subset,
    #                                          batch_size=batch_size,
    #                                          shuffle=False)

    test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
                                              batch_size=batch_size,
                                              shuffle=False)

    # Fully connected neural network
    class NeuralNet(nn.Module):
        def __init__(self, input_size, hidden_size, num_classes):
            super(NeuralNet, self).__init__()
            self.fc1 = nn.Linear(input_size, hidden_size)
            self.relu = nn.ReLU()
            self.fc2 = nn.Linear(hidden_size, num_classes)

        def forward(self, x):
            out = self.fc1(x)
            out = self.relu(out)
            out = self.fc2(out)
            return out

    model = NeuralNet(input_size, hidden_size, num_classes).to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # train the model
    print("size of dataset: ", len(train_loader.dataset))
    total_step = len(train_loader)
    for epoch in range(num_epochs):
        for i, (images, labels) in enumerate(train_loader):
            images = images.reshape(-1, input_size).to(device)
            labels = labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            if (i + 1) % batch_size == 0:
                print('Epoch [{}/{}], Step [{}/{}], Loss: {:.4f}'
                      .format(epoch + 1, num_epochs, i + 1, total_step, loss.item()))
    print("training complete.")
    with torch.no_grad():
        zi_lst = []
        labels = []
        for image, label in train_dataset:
            image = image.reshape(-1, input_size).to(device)
            labels.append(label)
            # hidden_layer = model.fc1(image)
            # zi = model.relu(hidden_layer)
            # zi_lst.append(np.array(zi.numpy()[0]))
            zi_lst.append(np.array(image.numpy()[0]))
        zi_lst = np.array(zi_lst)
    print("begin TSNE...")
    tsne = TSNE(n_components=2, perplexity=30)
    data_tsne = tsne.fit_transform(np.array(zi_lst))
    print("done.")
    colors = [COLORS[c] for c in labels]
    plt.scatter(data_tsne[:, 0], data_tsne[:, 1], c=colors)
    legend_items = [Patch(facecolor=COLORS[i], edgecolor=COLORS[i], label=i) for i in range(len(COLORS))]
    plt.legend(handles=legend_items)
    plt.show()

    return model


if __name__ == "__main__":
    params = (500, 100, 0.001)
    hidden, batch, learn = params
    print(f"NOW USING hidden size {hidden}, batch size {batch}, learning rate {learn}")
    main(params)
    plt.savefig(f"task5.png")
