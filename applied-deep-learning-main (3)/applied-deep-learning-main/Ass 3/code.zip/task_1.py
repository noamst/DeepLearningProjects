# based on https://github.com/milindmalshe/Fully-Connected-Neural-Network-PyTorch/blob/master/FCN_MNIST_Classification_PyTorch.py
import numpy as np
import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt

# Setup device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def main():
    # Hyperparameters
    input_size = 784
    hidden_size = 500
    num_classes = 10
    num_epochs = 5
    batch_size = 100
    learning_rate = 0.001

    # MNIST dataset
    train_dataset = torchvision.datasets.MNIST(root='./data/',
                                               train=True,
                                               transform=transforms.ToTensor(),
                                               download=True)

    test_dataset = torchvision.datasets.MNIST(root='./data/',
                                              train=False,
                                              transform=transforms.ToTensor())

    # Data loader
    train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
                                               batch_size=batch_size,
                                               shuffle=True)

    test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
                                              batch_size=batch_size,
                                              shuffle=False)

    # images, labels = next(iter(train_loader))
    #
    # fig, axs = plt.subplots(2, 5)
    # for ii in range(2):
    #     for jj in range(5):
    #         idx = 5 * ii + jj
    #         axs[ii, jj].imshow(images[idx].squeeze())
    #         axs[ii, jj].set_title(labels[idx].item())
    #         axs[ii, jj].axis('off')
    # plt.show()

    # Fully connected neural network
    class NeuralNet(nn.Module):
        def __init__(self, input_size, hidden_size, num_classes):
            super(NeuralNet, self).__init__()
            self.fc1 = nn.Linear(input_size, hidden_size)
            self.relu = nn.ReLU()
            self.fc2 = nn.Linear(hidden_size, num_classes)

        def forward(self, x):
            out = self.fc1(x)
            out = self.relu(out)
            out = self.fc2(out)
            return out

    model = NeuralNet(input_size, hidden_size, num_classes).to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # train the model
    print("size of dataset: ", len(train_loader.dataset))
    e_tr = []
    e_te = []
    total_step = len(train_loader)
    for epoch in range(num_epochs):
        accumulated_loss_train = 0
        accumulated_loss_test = 0
        for i, (images, labels) in enumerate(train_loader):
            images = images.reshape(-1, input_size).to(device)
            labels = labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            accumulated_loss_train += loss.item()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            if (i + 1) % 100 == 0:
                print('Epoch [{}/{}], Step [{}/{}], Loss: {:.4f}'
                      .format(epoch + 1, num_epochs, i + 1, total_step, loss.item()))
        # every epoch
        e_tr.append(accumulated_loss_train / len(train_loader.dataset))
        with torch.no_grad():
            for images, labels in test_loader:
                images = images.reshape(-1, input_size).to(device)
                labels = labels.to(device)
                outputs = model(images)
                loss = criterion(outputs, labels)
                accumulated_loss_test += loss.item()
            e_te.append(accumulated_loss_test / len(test_loader.dataset))
    print(e_te[-1])
    plt.plot(e_tr, label="E train")
    plt.plot(e_te, label="E test")
    plt.legend()
    plt.show()

    with torch.no_grad():
        correct = 0
        total = 0
        for images, labels in test_loader:
            images = images.reshape(-1, 28 * 28).to(device)
            labels = labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        print('Accuracy of the network on the 10000 test images: {} %'.format(100 * correct / total))

    bad_preds = []
    test_iter = iter(test_dataset)
    with torch.no_grad():
        while len(bad_preds) < 5:
            image1, label = next(test_iter)
            image = image1.reshape(-1, 28 * 28)
            output = model(image)
            _, predicted = torch.max(output, 1)
            predicted = predicted.item()
            if predicted != label:
                bad_preds.append((predicted, label, image1))

    fig, axs = plt.subplots(1, 5)
    for idx in range(5):
        axs[idx].imshow(bad_preds[idx][2].squeeze())
        axs[idx].set_title(f"p: {bad_preds[idx][0]} a:{bad_preds[idx][1]}")
        axs[idx].axis('off')
    plt.show()


if __name__ == "__main__":
    main()
